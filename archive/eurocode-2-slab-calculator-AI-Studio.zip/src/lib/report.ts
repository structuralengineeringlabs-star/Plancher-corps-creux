
import { CalculationResults, CalculationState, BorderCondition, AppuiType } from "../types";
import { EXPLOITATION_CATEGORIES } from "../constants";

export const formatNum = (n: number | undefined, digits = 2) => {
  if (n === undefined || n === null || isNaN(n)) return "-";
  return n.toLocaleString("fr-FR", { minimumFractionDigits: digits, maximumFractionDigits: digits });
};

export const generateNoteDeCalcul = (state: CalculationState, results: CalculationResults, projectName: string) => {
  const cat = EXPLOITATION_CATEGORIES[state.qkCategoryIndex];
  const globalOk = results.shearOk && results.deflectionOk && results.steelOk && results.crackOk && (!results.punchActive || results.punchingOk) && results.mu <= 0.372;

  return `
    <div style="font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; color: #1e293b; max-width: 900px; margin: 0 auto; padding: 40px; border: 1px solid #e2e8f0; background: #fff; line-height: 1.5;">
      <div style="display: flex; justify-content: space-between; align-items: start; border-bottom: 3px solid #1a5276; padding-bottom: 20px; margin-bottom: 30px;">
        <div style="display: flex; align-items: center; gap: 15px;">
          <div style="position: relative; width: 50px; height: 50px; flex-shrink: 0;">
            <svg viewBox="0 0 48 48" style="width: 50px; height: 50px;">
              <path d="M24 4 L44 14 L44 34 L24 44 L4 34 L4 14 Z" fill="#3a9bd5" fill-opacity="0.1" />
              <path d="M24 4 L44 14 L44 34 L24 44 L4 34 L4 14 Z" fill="none" stroke="#3a9bd5" stroke-width="2.5" />
              <rect x="16" y="18" width="16" height="12" rx="2" fill="#3a9bd5" />
            </svg>
            <span style="position: absolute; left: 50%; top: 50%; transform: translate(-50%, -50%); font-family: sans-serif; font-weight: 900; color: white; font-size: 11px; pointer-events: none;">S.E.L.</span>
          </div>
          <div style="display: flex; flex-direction: column; line-height: 1.1;">
            <div style="display: flex; align-items: baseline; gap: 2px;">
              <span style="font-family: sans-serif; font-weight: 900; font-size: 18px; letter-spacing: -0.5px; color: #0f172a;">STRUCTURAL</span>
              <span style="font-family: sans-serif; font-weight: 700; font-size: 18px; color: #3a9bd5;">&</span>
            </div>
            <span style="font-family: sans-serif; font-weight: 700; font-size: 10px; letter-spacing: 0.35em; color: #64748b; margin-top: 1px;">ENGINEERING LABS</span>
          </div>
        </div>
        <div style="text-align: right;">
          <h1 style="color: #1a5276; margin: 0; font-size: 22px; font-weight: 900; text-transform: uppercase; letter-spacing: 1px;">Note de Calcul Pro</h1>
          <p style="color: #64748b; margin: 4px 0 0; font-size: 12px; font-weight: 700;">Conception aux Eurocodes 2 | S.E.L. v2.0</p>
        </div>
      </div>

      <div style="margin-bottom: 30px; padding: 20px; background: #f8fafc; border-radius: 12px; border: 1px solid #e2e8f0; display: flex; justify-content: space-between; align-items: center;">
        <div style="font-size: 14px; color: #334155;">
          <strong style="color: #1a5276; text-transform: uppercase; font-size: 10px; display: block; margin-bottom: 2px;">Identification du Projet</strong>
          <span style="font-weight: 700; font-size: 16px;">${projectName}</span>
        </div>
        <div style="text-align: right; font-size: 14px; color: #64748b;">
          <strong style="color: #1a5276; text-transform: uppercase; font-size: 10px; display: block; margin-bottom: 2px;">Date d'Étude</strong>
          <span style="font-weight: 600;">${new Date().toLocaleDateString('fr-FR')}</span>
        </div>
      </div>

      <h2 style="color: #1a5276; border-bottom: 2px solid #cbd5e1; padding-bottom: 8px; font-size: 18px; margin-top: 40px; display: flex; align-items: center; gap: 10px;">
        <span style="background: #1a5276; color: #fff; width: 24px; height: 24px; display: inline-flex; align-items: center; justify-content: center; border-radius: 6px; font-size: 14px;">1</span>
        HYPOTHÈSES DES MATÉRIAUX
      </h2>
      <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 30px; margin-bottom: 25px;">
        <div style="background: #fff; padding: 15px; border-radius: 8px; border: 1px solid #f1f5f9;">
          <h3 style="font-size: 13px; color: #3a9bd5; margin: 0 0 10px; text-transform: uppercase; font-weight: 800;">Béton de Structure</h3>
          <table style="width: 100%; font-size: 12px; border-collapse: collapse;">
            <tr><td style="padding: 4px 0; color: #64748b;">Classe de béton</td><td style="text-align: right; font-weight: 700;">C${state.fck}/${Math.round(state.fck * 1.2)}</td></tr>
            <tr><td style="padding: 4px 0; color: #64748b;">fck (Compression)</td><td style="text-align: right; font-weight: 700;">${results.fck} MPa</td></tr>
            <tr><td style="padding: 4px 0; color: #64748b;">fcd (Calcul)</td><td style="text-align: right; font-weight: 700;">${formatNum(results.fcd, 2)} MPa</td></tr>
            <tr><td style="padding: 4px 0; color: #64748b;">fctm (Traction moy)</td><td style="text-align: right; font-weight: 700;">${formatNum(results.fctm, 2)} MPa</td></tr>
            <tr><td style="padding: 4px 0; color: #64748b;">Ecm (Module Young)</td><td style="text-align: right; font-weight: 700;">${Math.round(results.Ecm)} MPa</td></tr>
          </table>
        </div>
        <div style="background: #fff; padding: 15px; border-radius: 8px; border: 1px solid #f1f5f9;">
          <h3 style="font-size: 13px; color: #3a9bd5; margin: 0 0 10px; text-transform: uppercase; font-weight: 800;">Aciers & Durabilité</h3>
          <table style="width: 100%; font-size: 12px; border-collapse: collapse;">
            <tr><td style="padding: 4px 0; color: #64748b;">Type d'Acier</td><td style="text-align: right; font-weight: 700;">Haute Adhérence B500</td></tr>
            <tr><td style="padding: 4px 0; color: #64748b;">fyk (Limite élastique)</td><td style="text-align: right; font-weight: 700;">${results.fyk} MPa</td></tr>
            <tr><td style="padding: 4px 0; color: #64748b;">Exposition</td><td style="text-align: right; font-weight: 700;">${state.exposure} / X0</td></tr>
            <tr><td style="padding: 4px 0; color: #64748b;">Enrobage cnom</td><td style="text-align: right; font-weight: 700;">${results.cnom} mm</td></tr>
            <tr><td style="padding: 4px 0; color: #64748b;">Hauteur utile d</td><td style="text-align: right; font-weight: 700;">${results.d} mm</td></tr>
          </table>
        </div>
      </div>

      <h2 style="color: #1a5276; border-bottom: 2px solid #cbd5e1; padding-bottom: 8px; font-size: 18px; margin-top: 30px; display: flex; align-items: center; gap: 10px;">
        <span style="background: #1a5276; color: #fff; width: 24px; height: 24px; display: inline-flex; align-items: center; justify-content: center; border-radius: 6px; font-size: 14px;">2</span>
        DONNÉES GÉOMÉTRIQUES & CHARGES
      </h2>
      <div style="background: #f8fafc; padding: 20px; border-radius: 12px; margin-bottom: 25px;">
        <table style="width: 100%; border-collapse: collapse; font-size: 13px;">
          <tr style="border-bottom: 1px solid #e2e8f0;">
            <td style="padding: 10px 0; font-weight: 600;">Géométrie de la Dalle</td>
            <td style="text-align: right;">${state.Lx} m (Lx) × ${state.Ly} m (Ly) | h = ${state.h} cm</td>
          </tr>
          <tr style="border-bottom: 1px solid #e2e8f0;">
            <td style="padding: 10px 0; font-weight: 600;">Schéma Statique</td>
            <td style="text-align: right;">${state.appuiType === AppuiType.FourSides ? 'Appuyée sur 4 côtés' : 'Appuyée sur 2 côtés'} | ${state.borderCond === BorderCondition.SimplySupported ? 'Articulation simple' : 'Continuité / Encastrement'}</td>
          </tr>
          <tr style="border-bottom: 1px solid #e2e8f0;">
            <td style="padding: 10px 0; font-weight: 600;">Charges Permanentes G</td>
            <td style="text-align: right;">${formatNum(results.g_total, 2)} kN/m² (Poids propre + G additionnel)</td>
          </tr>
          <tr style="border-bottom: 1px solid #e2e8f0;">
            <td style="padding: 10px 0; font-weight: 600;">Charges d'Exploitation Q</td>
            <td style="text-align: right;">${formatNum(results.qk, 2)} kN/m² (${cat.label})</td>
          </tr>
          <tr style="background: #1a5276; color: white;">
            <td style="padding: 10px 8px; font-weight: 700;">Combinaison Ultime ELU (pu = 1.35G + 1.5Q)</td>
            <td style="text-align: right; padding-right: 8px; font-weight: 800; font-size: 15px;">${formatNum(results.pu, 2)} kN/m²</td>
          </tr>
        </table>
      </div>

      <h2 style="color: #1a5276; border-bottom: 2px solid #cbd5e1; padding-bottom: 8px; font-size: 18px; margin-top: 30px; display: flex; align-items: center; gap: 10px;">
        <span style="background: #1a5276; color: #fff; width: 24px; height: 24px; display: inline-flex; align-items: center; justify-content: center; border-radius: 6px; font-size: 14px;">3</span>
        ANALYSE DES SOLLICITATIONS (SOLUTIONS ANALYTIQUES)
      </h2>
      <div style="margin-bottom: 25px;">
        <p style="font-size: 13px; color: #64748b; margin-bottom: 15px;">Les moments sont calculés suivant les théories des plaques minces et les coefficients de redistribution Eurocode 2.</p>
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
          <div style="padding: 15px; border: 1px solid #e2e8f0; border-radius: 8px; background: #fff;">
            <h4 style="margin: 0 0 10px; font-size: 11px; color: #1a5276; text-transform: uppercase; font-weight: 800;">Moments en Travée (kNm/m)</h4>
            <div style="display: flex; justify-content: space-between; font-size: 14px; font-weight: 700;">
              <span style="color: #334155;">Mx : ${formatNum(results.MEd_x, 2)}</span>
              <span style="color: #334155;">My : ${formatNum(results.MEd_y, 2)}</span>
            </div>
          </div>
          <div style="padding: 15px; border: 1px solid #e2e8f0; border-radius: 8px; background: #fff;">
            <h4 style="margin: 0 0 10px; font-size: 11px; color: #1a5276; text-transform: uppercase; font-weight: 800;">Moments aux Appuis (kNm/m)</h4>
            <div style="font-size: 14px; font-weight: 700; text-align: center; color: #334155;">
              M_appui : ${formatNum(results.MEd_app_x, 2)}
            </div>
          </div>
        </div>
      </div>

      <h2 style="color: #1a5276; border-bottom: 2px solid #cbd5e1; padding-bottom: 8px; font-size: 18px; margin-top: 30px; display: flex; align-items: center; gap: 10px;">
        <span style="background: #1a5276; color: #fff; width: 24px; height: 24px; display: inline-flex; align-items: center; justify-content: center; border-radius: 6px; font-size: 14px;">4</span>
        ÉTATS LIMITES ULTIMES & SERVICE (EC2)
      </h2>
      <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 25px;">
        <div style="padding: 15px; border-radius: 12px; background: ${results.mu <= 0.372 ? '#f0fdf4' : '#fef2f2'}; border: 1px solid ${results.mu <= 0.372 ? '#bbf7d0' : '#fecaca'};">
          <h4 style="margin: 0 0 5px; font-size: 12px; font-weight: 800; color: ${results.mu <= 0.372 ? '#166534' : '#991b1b'};">Flexion ELU</h4>
          <div style="font-size: 11px; color: #64748b;">μ = ${formatNum(results.mu, 4)} | μ_lim = 0.372</div>
          <p style="font-size: 12px; font-weight: 800; margin-top: 8px;">${results.mu <= 0.372 ? '✓ ARMATURES TENDUES UNIQUEMENT' : '✗ SECTION INSUFFISANTE'}</p>
        </div>
        <div style="padding: 15px; border-radius: 12px; background: ${results.shearOk ? '#f0fdf4' : '#fef2f2'}; border: 1px solid ${results.shearOk ? '#bbf7d0' : '#fecaca'};">
          <h4 style="margin: 0 0 5px; font-size: 12px; font-weight: 800; color: ${results.shearOk ? '#166534' : '#991b1b'};">Cisaillement</h4>
          <div style="font-size: 11px; color: #64748b;">VEd = ${formatNum(results.VEd, 1)} kN | VRd,c = ${formatNum(results.VRd_c, 1)} kN</div>
          <p style="font-size: 12px; font-weight: 800; margin-top: 8px;">${results.shearOk ? '✓ CONFORME SANS ÉTRIERS' : '✗ EFFORT TROP ÉLEVÉ'}</p>
        </div>
        <div style="padding: 15px; border-radius: 12px; background: ${results.crackOk ? '#f0fdf4' : '#fef2f2'}; border: 1px solid ${results.crackOk ? '#bbf7d0' : '#fecaca'};">
          <h4 style="margin: 0 0 5px; font-size: 12px; font-weight: 800; color: ${results.crackOk ? '#166534' : '#991b1b'};">Fissuration ELS</h4>
          <div style="font-size: 11px; color: #64748b;">wk = ${formatNum(results.wk, 3)} mm | w_lim = ${results.w_max} mm</div>
          <p style="font-size: 12px; font-weight: 800; margin-top: 8px;">${results.crackOk ? '✓ OUVERTURE MAÎTRISÉE' : '✗ RISQUE DE FISSURATION'}</p>
        </div>
        <div style="padding: 15px; border-radius: 12px; background: ${results.deflectionOk ? '#f0fdf4' : '#fef2f2'}; border: 1px solid ${results.deflectionOk ? '#bbf7d0' : '#fecaca'};">
          <h4 style="margin: 0 0 5px; font-size: 12px; font-weight: 800; color: ${results.deflectionOk ? '#166534' : '#991b1b'};">Déformabilité (ELS)</h4>
          <div style="font-size: 11px; color: #64748b;">L/d = ${formatNum(results.Ld_real, 1)} | L/d_lim = ${formatNum(results.limitLd, 1)}</div>
          <p style="font-size: 12px; font-weight: 800; margin-top: 8px;">${results.deflectionOk ? '✓ ÉTAT DE FLÈCHE ADMISSIBLE' : '✗ FLÈCHE EXCESSIVE'}</p>
        </div>
      </div>

      ${results.punchActive ? `
      <div style="margin-bottom: 25px; padding: 20px; border-radius: 16px; background: ${results.punchingOk ? '#f0fdf4' : '#fef2f2'}; border: 2px solid ${results.punchingOk ? '#bbf7d0' : '#fecaca'};">
         <h4 style="margin: 0 0 10px; font-size: 14px; font-weight: 900; color: ${results.punchingOk ? '#166534' : '#991b1b'}; text-transform: uppercase; letter-spacing: 1px;">Vérification au Poinçonnement (EC2 6.4) - Position: ${state.columnPosition}</h4>
         <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 15px; font-size: 13px;">
           <div><span style="color: #64748b; font-size: 11px; display: block;">Effort Ultime VEd</span><strong>${formatNum(results.VEd_punch, 1)} kN</strong></div>
           <div><span style="color: #64748b; font-size: 11px; display: block;">Résistance VRd,c</span><strong>${formatNum(results.VRd_c_punch, 1)} kN</strong></div>
           <div style="text-align: right;"><span style="color: #64748b; font-size: 11px; display: block;">Verdict</span><strong style="color: ${results.punchingOk ? '#166534' : '#991b1b'};">${results.punchingOk ? 'CONFORME ✓' : 'INSUFFISANT ✗'}</strong></div>
         </div>
      </div>
      ` : ''}

      <h2 style="color: #1a5276; border-bottom: 2px solid #cbd5e1; padding-bottom: 8px; font-size: 18px; margin-top: 30px; display: flex; align-items: center; gap: 10px;">
        <span style="background: #1a5276; color: #fff; width: 24px; height: 24px; display: inline-flex; align-items: center; justify-content: center; border-radius: 6px; font-size: 14px;">5</span>
        DISPOSITIONS CONSTRUCTIVES & NOMENCLATURE (BBS)
      </h2>
      <div style="background: #fff; border: 2px solid #e2e8f0; border-radius: 16px; overflow: hidden; margin-bottom: 30px; box-shadow: 0 4px 6px -1px rgb(0 0 0 / 0.1);">
        <table style="width: 100%; border-collapse: collapse; font-size: 12px;">
          <thead>
            <tr style="background: #f1f5f9; text-align: left; color: #334155; border-bottom: 2px solid #e2e8f0;">
              <th style="padding: 15px 12px; font-weight: 800;">REPERE</th>
              <th style="padding: 15px 12px; font-weight: 800;">DÉSIGNATION DES ARMATURES</th>
              <th style="padding: 15px 12px; text-align: center; font-weight: 800;">ϕ (mm)</th>
              <th style="padding: 15px 12px; text-align: center; font-weight: 800;">NB</th>
              <th style="padding: 15px 12px; text-align: center; font-weight: 800;">L (m)</th>
              <th style="padding: 15px 12px; text-align: right; font-weight: 800;">POIDS (kg)</th>
            </tr>
          </thead>
          <tbody>
            <tr style="border-bottom: 1px solid #f1f5f9; background: #fff;">
              <td style="padding: 12px; font-weight: 800; color: #1a5276;">1</td>
              <td style="padding: 12px; font-weight: 600;">Nappe Inférieure - Sens Porteur (Lx)</td>
              <td style="padding: 12px; text-align: center; font-weight: 700;">${state.diam_inf_x}</td>
              <td style="padding: 12px; text-align: center;">${results.qty_x}</td>
              <td style="padding: 12px; text-align: center;">${state.Lx}</td>
              <td style="padding: 12px; text-align: right; font-weight: 800;">${formatNum(results.weight_x, 2)}</td>
            </tr>
            <tr style="border-bottom: 1px solid #f1f5f9; background: #fbfcfd;">
              <td style="padding: 12px; font-weight: 800; color: #1a5276;">2</td>
            <td style="padding: 12px; font-weight: 600;">${state.appuiType === AppuiType.FourSides ? 'Nappe Inférieure - Sens Ly' : 'Armatures de Répartition - Ly'}</td>
              <td style="padding: 12px; text-align: center; font-weight: 700;">${state.appuiType === AppuiType.FourSides ? state.diam_inf_y : 8}</td>
              <td style="padding: 12px; text-align: center;">${results.qty_y}</td>
              <td style="padding: 12px; text-align: center;">${state.Ly}</td>
              <td style="padding: 12px; text-align: right; font-weight: 800;">${formatNum(results.weight_y, 2)}</td>
            </tr>
            ${results.weight_top > 0 ? `
            <tr style="border-bottom: 1px solid #f1f5f9; background: #fff;">
              <td style="padding: 12px; font-weight: 800; color: #1a5276;">3</td>
              <td style="padding: 12px; font-weight: 600;">Armatures de Chapeaux (Moments sur appuis)</td>
              <td style="padding: 12px; text-align: center; font-weight: 700;">${state.diam_inf_x}</td>
              <td style="padding: 12px; text-align: center;">${results.qty_top}</td>
              <td style="padding: 12px; text-align: center;">${results.len_top}</td>
              <td style="padding: 12px; text-align: right; font-weight: 800;">${formatNum(results.weight_top, 2)}</td>
            </tr>
            ` : ''}
            <tr style="background: #0f172a; color: white;">
              <td colspan="5" style="padding: 15px 12px; text-align: right; font-weight: 700; text-transform: uppercase; letter-spacing: 2px; font-size: 11px;">Masse Totale des Armatures</td>
              <td style="padding: 15px 12px; text-align: right; font-weight: 900; font-size: 16px; color: #3a9bd5;">${formatNum(results.weight_total, 2)} kg</td>
            </tr>
          </tbody>
        </table>
      </div>

      <div style="margin-top: 40px; padding: 25px; border: 3px solid ${globalOk ? '#166534' : '#991b1b'}; background: ${globalOk ? '#f0fdf4' : '#fef2f2'}; border-radius: 16px; text-align: center; box-shadow: 0 10px 15px -3px rgb(0 0 0 / 0.1);">
        <div style="font-weight: 950; font-size: 24px; color: ${globalOk ? '#166534' : '#991b1b'}; letter-spacing: 4px; text-transform: uppercase; margin-bottom: 5px;">
          ${globalOk ? 'Conception Validée ✓' : 'Dimensionnement Invalide ✗'}
        </div>
        <p style="margin: 0; font-size: 12px; color: ${globalOk ? '#166534' : '#991b1b'}; font-weight: 700; opacity: 0.8;">
          Note de calcul générée en conformité avec la NF EN 1992-1-1
        </p>
      </div>

      <div style="margin-top: 60px; padding-top: 40px; border-top: 2px solid #f1f5f9; display: flex; justify-content: space-between; align-items: end;">
        <div style="max-width: 250px;">
          <p style="margin: 0; font-size: 13px; font-weight: 900; color: #0f172a;">VISA DE L'INGÉNIEUR</p>
          <p style="margin: 6px 0 0; font-size: 11px; color: #64748b; font-style: italic;">Cachet et signature pour approbation technique</p>
          <div style="margin-top: 20px; width: 180px; height: 75px; border: 2px dashed #e2e8f0; border-radius: 8px; background: #fafafa; display: flex; align-items: center; justify-content: center; color: #e2e8f0; font-size: 8px;">CADRE RÉSERVÉ</div>
        </div>
        <div style="text-align: right;">
          <div style="display: flex; flex-direction: column; gap: 4px; font-size: 12px; color: #334155; font-weight: 600;">
            <p style="margin: 0; color: #1a5276; font-weight: 900; font-size: 10px; text-transform: uppercase; letter-spacing: 1px;">Expertise Structurelle</p>
            <p style="margin: 0;">S.E.L. - Ingénierie du Béton Armé</p>
            <p style="margin: 0;">E-mail : structuralengineeringlabs@gmail.com</p>
            <p style="margin: 0;">Tél : +237 6 51 13 56 05</p>
          </div>
          <p style="margin-top: 15px; font-size: 9px; color: #94a3b8; font-weight: 500;">Page 1 sur 1 | Système Expert S.E.L. v2.0</p>
        </div>
      </div>
    </div>
  `;
};
