
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useMemo, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Calculator, 
  Settings, 
  CheckCircle2, 
  AlertCircle, 
  FileText, 
  Layers, 
  ChevronDown, 
  Save, 
  FolderOpen, 
  Trash2, 
  Printer, 
  FileDown, 
  Moon, 
  Sun,
  Layout,
  Maximize2,
  HelpCircle,
  Hash,
  Info,
  Zap,
  Activity
} from 'lucide-react';
import { 
  AppuiType, 
  BorderCondition, 
  CalculationState, 
  ColumnPosition 
} from './types';
import { 
  FCK_OPTIONS, 
  FCK_MAP, 
  FYK_OPTIONS, 
  EXPOSURE_OPTIONS, 
  STRUCT_CLASS_OPTIONS, 
  DELTA_CDEV_OPTIONS, 
  DIAM_OPTIONS, 
  G1_OPTIONS, 
  EXPLOITATION_CATEGORIES 
} from './constants';
import { computeAll } from './lib/calculations';
import { formatNum } from './lib/report';
import { generateNoteDeCalcul } from './lib/report';
import { SlabVisualization } from './components/SlabVisualization';
import { SEL_Logo } from './components/Logo';
import jsPDF from 'jspdf';
import html2pdf from 'html2pdf.js';

export default function App() {
  const [state, setState] = useState<CalculationState>({
    appuiType: AppuiType.FourSides,
    borderCond: BorderCondition.SimplySupported,
    fck: 25,
    fyk: 500,
    exposure: "XC2",
    structClass: "S4",
    deltaCdev: 10,
    h: 200,
    Lx: 5.0,
    Ly: 6.0,
    phi: 12,
    g1: 1.5,
    qkCategoryIndex: 0,
    diam_inf_x: 12,
    diam_inf_y: 10,
    checkPunching: true,
    columnSize: 300,
    columnPosition: ColumnPosition.Central
  });

  const [activeTab, setActiveTab] = useState('input');
  const [projectName, setProjectName] = useState('Projet Dalle EC2');
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [savedProjects, setSavedProjects] = useState<string[]>([]);

  const results = useMemo(() => computeAll(state), [state]);

  useEffect(() => {
    const projects = JSON.parse(localStorage.getItem('ec2_projects') || '{}');
    setSavedProjects(Object.keys(projects));
    
    if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
      setIsDarkMode(true);
    }
  }, []);

  const updateState = (updates: Partial<CalculationState>) => {
    setState(prev => ({ ...prev, ...updates }));
  };

  const [saveSuccess, setSaveSuccess] = useState(false);

  const handleSave = () => {
    const projects = JSON.parse(localStorage.getItem('ec2_projects') || '{}');
    projects[projectName] = state;
    localStorage.setItem('ec2_projects', JSON.stringify(projects));
    setSavedProjects(Object.keys(projects));
    
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2000);
  };

  const handleLoad = (name: string) => {
    const projects = JSON.parse(localStorage.getItem('ec2_projects') || '{}');
    if (projects[name]) {
      setState(projects[name]);
      setProjectName(name);
    }
  };

  const handleDelete = () => {
    const projects = JSON.parse(localStorage.getItem('ec2_projects') || '{}');
    delete projects[projectName];
    localStorage.setItem('ec2_projects', JSON.stringify(projects));
    setSavedProjects(Object.keys(projects));
    alert(`Projet "${projectName}" supprimé.`);
  };

  const handleExportPDF = () => {
    const content = generateNoteDeCalcul(state, results, projectName);
    const element = document.createElement('div');
    element.innerHTML = content;
    
    const opt = {
      margin: 10,
      filename: `${projectName}.pdf`,
      image: { type: 'jpeg' as const, quality: 0.98 },
      html2canvas: { 
        scale: 2, 
        useCORS: true, 
        logging: false,
        letterRendering: true
      },
      jsPDF: { unit: 'mm' as const, format: 'a4' as const, orientation: 'portrait' as const }
    };

    html2pdf().set(opt).from(element).save();
  };

  const globalOk = results.shearOk && results.deflectionOk && results.steelOk && results.crackOk && (!results.punchActive || results.punchingOk) && results.mu <= 0.372;

  const TabButton = ({ id, label, icon: Icon }: { id: string, label: string, icon: any }) => (
    <button
      onClick={() => setActiveTab(id)}
      className={`flex items-center gap-2 px-6 py-3 rounded-xl font-semibold transition-all duration-200 whitespace-nowrap ${
        activeTab === id 
          ? 'bg-blue-600 text-white shadow-lg shadow-blue-200' 
          : 'text-slate-500 hover:bg-slate-100 hover:text-slate-800'
      }`}
    >
      <Icon size={18} />
      {label}
    </button>
  );

  return (
    <div className={`min-h-screen ${isDarkMode ? 'bg-slate-950 text-slate-100' : 'bg-slate-50 text-slate-900'} p-4 md:p-8 font-sans`}>
      <header className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-start md:items-center gap-6 mb-10">
        <SEL_Logo />
        
        <div className="flex flex-wrap items-center gap-3">
          <button onClick={() => setIsDarkMode(!isDarkMode)} className="p-3 bg-white border border-slate-200 rounded-xl hover:bg-slate-50 transition-colors shadow-sm">
            {isDarkMode ? <Sun size={20} className="text-amber-500" /> : <Moon size={20} className="text-slate-600" />}
          </button>
          <button 
            onClick={handleSave} 
            className={`flex items-center gap-2 px-5 py-3 rounded-xl font-semibold transition-all shadow-sm ${
              saveSuccess 
                ? 'bg-emerald-500 text-white border-emerald-500' 
                : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-50'
            }`}
          >
            {saveSuccess ? (
              <><CheckCircle2 size={18} /> Enregistré</>
            ) : (
              <><Save size={18} /> Sauvegarder</>
            )}
          </button>
          <button onClick={handleExportPDF} className="flex items-center gap-2 px-5 py-3 bg-blue-600 text-white rounded-xl font-semibold hover:bg-blue-700 transition-all shadow-lg shadow-blue-100">
            <Printer size={18} /> Imprimer le Rapport
          </button>
        </div>
      </header>

      <main className="max-w-7xl mx-auto">
        <section className="flex flex-col lg:flex-row gap-6 mb-8">
          <div className="flex-1 bg-white border border-slate-200 rounded-2xl p-4 md:p-6 shadow-sm flex flex-wrap items-center gap-4">
            <div className="flex-1 min-w-[200px] flex items-end gap-2">
              <div className="flex-1">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-1">Nom du Projet</label>
                <input 
                  type="text" 
                  value={projectName} 
                  onChange={(e) => setProjectName(e.target.value)}
                  className="w-full bg-slate-50 border-none rounded-lg px-4 py-2 font-bold text-lg focus:ring-2 focus:ring-blue-100 transition-all"
                />
              </div>
              {savedProjects.length > 0 && (
                <div className="relative group">
                  <select 
                    onChange={(e) => handleLoad(e.target.value)}
                    className="appearance-none bg-slate-100 hover:bg-slate-200 text-slate-600 px-3 py-2 rounded-lg text-xs font-bold transition-colors cursor-pointer border-none outline-none"
                    value=""
                  >
                    <option value="" disabled>📁 Projets ({savedProjects.length})</option>
                    {savedProjects.map(name => <option key={name} value={name}>{name}</option>)}
                  </select>
                </div>
              )}
              <button 
                onClick={handleDelete}
                className="p-2 text-slate-300 hover:text-rose-500 transition-colors"
                title="Supprimer le projet actuel"
              >
                <Trash2 size={18} />
              </button>
            </div>
            <div className="w-full md:w-px h-px md:h-10 bg-slate-100"></div>
            <div className="flex flex-wrap gap-4 flex-1">
              <div className="flex-1 text-center">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-1">Épaisseur h</span>
                <span className="text-xl font-black text-blue-600">{state.h} <span className="text-xs font-medium text-slate-400">mm</span></span>
              </div>
              <div className="flex-1 text-center">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-1">Charge ELU</span>
                <span className="text-xl font-black text-blue-600">{formatNum(results.pu, 2)} <span className="text-xs font-medium text-slate-400">kN/m²</span></span>
              </div>
              <div className="flex-1 text-center">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-1">Section Acier</span>
                <span className="text-xl font-black text-blue-600">{formatNum(results.As_req_x/100, 2)} <span className="text-xs font-medium text-slate-400">cm²/m</span></span>
              </div>
              <div className="flex-1 text-center">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-1">Statut</span>
                <span className={`text-xl font-black ${globalOk ? 'text-emerald-500' : 'text-rose-500'}`}>{globalOk ? 'VALIDE' : 'ÉCHEC'}</span>
              </div>
            </div>
          </div>
        </section>

        <nav className="flex gap-2 overflow-x-auto pb-4 no-scrollbar mb-8">
          <TabButton id="input" label="Données" icon={Settings} />
          <TabButton id="results" label="Résultats" icon={Layers} />
          <TabButton id="checks" label="Vérifications" icon={CheckCircle2} />
          <TabButton id="reinforcement" label="Ferraillage" icon={Layers} />
          <TabButton id="report" label="Note de Calcul" icon={FileText} />
          <TabButton id="help" label="Aide" icon={HelpCircle} />
        </nav>

        <AnimatePresence mode="wait">
          {activeTab === 'input' && (
            <motion.div 
              key="input"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="grid grid-cols-1 lg:grid-cols-2 gap-8"
            >
              <div className="space-y-8">
                <div className="bg-white border border-slate-200 rounded-3xl p-8 shadow-sm">
                  <h3 className="text-lg font-bold flex items-center gap-3 text-slate-800 mb-8 pb-4 border-bottom border-slate-100">
                    <Layout className="text-blue-500" size={20} />
                    Géométrie & Appuis
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Type d'appui</label>
                      <select 
                        value={state.appuiType} 
                        onChange={(e) => updateState({ appuiType: e.target.value as AppuiType })}
                        className="w-full bg-slate-50 border border-slate-100 rounded-xl px-4 py-3 font-semibold focus:ring-2 focus:ring-blue-100 transition-all outline-none"
                      >
                        <option value={AppuiType.TwoSides}>Sur 2 côtés (Lx)</option>
                        <option value={AppuiType.FourSides}>Sur 4 côtés (Lx × Ly)</option>
                      </select>
                    </div>
                    <div className="space-y-2">
                      <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Bords</label>
                      <select 
                        value={state.borderCond} 
                        onChange={(e) => updateState({ borderCond: e.target.value as BorderCondition })}
                        className="w-full bg-slate-50 border border-slate-100 rounded-xl px-4 py-3 font-semibold focus:ring-2 focus:ring-blue-100 transition-all outline-none"
                      >
                        <option value={BorderCondition.SimplySupported}>Simplement appuyé</option>
                        <option value={BorderCondition.Continuous}>Bords continus</option>
                        <option value={BorderCondition.Fixed}>Bords encastrés</option>
                      </select>
                    </div>
                    <div className="space-y-2">
                      <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Portée Lx (m)</label>
                      <input 
                        type="number" 
                        step="0.1"
                        value={state.Lx} 
                        onChange={(e) => updateState({ Lx: parseFloat(e.target.value) || 0 })}
                        className="w-full bg-slate-50 border border-slate-100 rounded-xl px-4 py-3 font-semibold focus:ring-2 focus:ring-blue-100 transition-all outline-none"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Portée Ly (m)</label>
                      <input 
                        type="number" 
                        step="0.1"
                        value={state.Ly} 
                        onChange={(e) => updateState({ Ly: parseFloat(e.target.value) || 0 })}
                        disabled={state.appuiType === AppuiType.TwoSides}
                        className="w-full bg-slate-50 border border-slate-100 rounded-xl px-4 py-3 font-semibold focus:ring-2 focus:ring-blue-100 transition-all outline-none disabled:opacity-50"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Épaisseur h (mm)</label>
                      <input 
                        type="number" 
                        step="10"
                        value={state.h} 
                        onChange={(e) => updateState({ h: parseFloat(e.target.value) || 0 })}
                        className="w-full bg-slate-50 border border-slate-100 rounded-xl px-4 py-3 font-semibold focus:ring-2 focus:ring-blue-100 transition-all outline-none"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Diamètre ϕ (mm)</label>
                      <select 
                        value={state.phi} 
                        onChange={(e) => updateState({ phi: parseInt(e.target.value) })}
                        className="w-full bg-slate-50 border border-slate-100 rounded-xl px-4 py-3 font-semibold focus:ring-2 focus:ring-blue-100 transition-all outline-none"
                      >
                        {DIAM_OPTIONS.map(d => <option key={d} value={d}>ϕ {d}</option>)}
                      </select>
                    </div>
                  </div>
                </div>

                <div className="bg-white border border-slate-200 rounded-3xl p-8 shadow-sm">
                  <h3 className="text-lg font-bold flex items-center gap-3 text-slate-800 mb-8 pb-4 border-bottom border-slate-100">
                    <Maximize2 className="text-amber-500" size={20} />
                    Matériaux & Exposition
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Béton (fck)</label>
                      <select 
                        value={state.fck} 
                        onChange={(e) => updateState({ fck: FCK_MAP[e.target.value] })}
                        className="w-full bg-slate-50 border border-slate-100 rounded-xl px-4 py-3 font-semibold focus:ring-2 focus:ring-blue-100 transition-all outline-none"
                      >
                        {FCK_OPTIONS.map(o => <option key={o} value={o}>{o}</option>)}
                      </select>
                    </div>
                    <div className="space-y-2">
                      <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Acier (fyk)</label>
                      <select 
                        value={state.fyk} 
                        onChange={(e) => updateState({ fyk: parseInt(e.target.value) })}
                        className="w-full bg-slate-50 border border-slate-100 rounded-xl px-4 py-3 font-semibold focus:ring-2 focus:ring-blue-100 transition-all outline-none"
                      >
                        {FYK_OPTIONS.map(o => <option key={o} value={o}>{o} MPa</option>)}
                      </select>
                    </div>
                    <div className="space-y-2">
                      <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Classe Exposition</label>
                      <select 
                        value={state.exposure} 
                        onChange={(e) => updateState({ exposure: e.target.value })}
                        className="w-full bg-slate-50 border border-slate-100 rounded-xl px-4 py-3 font-semibold focus:ring-2 focus:ring-blue-100 transition-all outline-none"
                      >
                        {EXPOSURE_OPTIONS.map(o => <option key={o} value={o}>{o}</option>)}
                      </select>
                    </div>
                    <div className="space-y-2">
                      <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Structurelle</label>
                      <select 
                        value={state.structClass} 
                        onChange={(e) => updateState({ structClass: e.target.value })}
                        className="w-full bg-slate-50 border border-slate-100 rounded-xl px-4 py-3 font-semibold focus:ring-2 focus:ring-blue-100 transition-all outline-none"
                      >
                        {STRUCT_CLASS_OPTIONS.map(o => <option key={o} value={o}>{o}</option>)}
                      </select>
                    </div>
                  </div>
                </div>

                {state.appuiType === AppuiType.FourSides && (
                  <div className="bg-white border border-slate-200 rounded-3xl p-8 shadow-sm">
                    <h3 className="text-lg font-bold flex items-center gap-3 text-slate-800 mb-8 pb-4 border-bottom border-slate-100">
                      <AlertCircle className="text-rose-500" size={20} />
                      Vérification au Poinçonnement
                    </h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Activer le calcul</label>
                        <select 
                          value={state.checkPunching ? "true" : "false"} 
                          onChange={(e) => updateState({ checkPunching: e.target.value === "true" })}
                          className="w-full bg-slate-50 border border-slate-100 rounded-xl px-4 py-3 font-semibold focus:ring-2 focus:ring-blue-100 transition-all outline-none"
                        >
                          <option value="true">Oui</option>
                          <option value="false">Non</option>
                        </select>
                      </div>
                      <div className="space-y-2">
                        <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Position Poteau</label>
                        <select 
                          value={state.columnPosition} 
                          onChange={(e) => updateState({ columnPosition: e.target.value as ColumnPosition })}
                          className="w-full bg-slate-50 border border-slate-100 rounded-xl px-4 py-3 font-semibold focus:ring-2 focus:ring-blue-100 transition-all outline-none"
                        >
                          <option value={ColumnPosition.Central}>Central (β = 1.15)</option>
                          <option value={ColumnPosition.Edge}>Rive (β = 1.40)</option>
                          <option value={ColumnPosition.Corner}>Angle (β = 1.50)</option>
                        </select>
                      </div>
                      <div className="space-y-2">
                        <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Taille Poteau (mm)</label>
                        <input 
                          type="number" 
                          step="50"
                          value={state.columnSize} 
                          onChange={(e) => updateState({ columnSize: parseFloat(e.target.value) || 0 })}
                          className="w-full bg-slate-50 border border-slate-100 rounded-xl px-4 py-3 font-semibold focus:ring-2 focus:ring-blue-100 transition-all outline-none"
                        />
                      </div>
                    </div>
                  </div>
                )}
              </div>

              <div className="space-y-8">
                <div className="bg-white border border-slate-200 rounded-3xl p-8 shadow-sm h-full flex flex-col">
                  <h3 className="text-lg font-bold text-slate-800 mb-8 pb-4 border-bottom border-slate-100 flex justify-between items-center">
                    Visualisation
                    <span className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Aperçu interactif</span>
                  </h3>
                  <div className="flex-1 min-h-[350px]">
                    <SlabVisualization state={state} results={results} />
                  </div>
                  
                  <div className="mt-8 grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="bg-slate-50 rounded-2xl p-6 border border-slate-100">
                      <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-4">Charges appliqué</h4>
                      <div className="space-y-4">
                        <div className="flex justify-between items-center">
                          <span className="text-sm font-medium text-slate-600">Permanente (G)</span>
                          <span className="font-bold text-slate-900">{formatNum(results.g_total, 2)} <span className="text-[10px] text-slate-400">kN/m²</span></span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm font-medium text-slate-600">Exploitation (Q)</span>
                          <span className="font-bold text-slate-900">{formatNum(results.qk, 2)} <span className="text-[10px] text-slate-400">kN/m²</span></span>
                        </div>
                        <div className="pt-3 border-t border-slate-200 flex justify-between items-center">
                          <span className="text-sm font-bold text-blue-600 uppercase">Ultime (pu)</span>
                          <span className="font-black text-blue-600 text-lg">{formatNum(results.pu, 2)} <span className="text-[10px]">kN/m²</span></span>
                        </div>
                      </div>
                    </div>
                    
                    <div className="bg-slate-50 rounded-2xl p-6 border border-slate-100">
                      <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-4">Durabilité</h4>
                      <div className="space-y-4">
                        <div className="flex justify-between items-center">
                          <span className="text-sm font-medium text-slate-600">cnom</span>
                          <span className="font-bold text-amber-600">{results.cnom} <span className="text-[10px]">mm</span></span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm font-medium text-slate-600">Hauteur utile (d)</span>
                          <span className="font-bold text-slate-900">{formatNum(results.d, 1)} <span className="text-[10px]">mm</span></span>
                        </div>
                        <div className="pt-3 border-t border-slate-200 flex justify-between items-center">
                          <span className="text-sm font-medium text-slate-600">Ratio L/d</span>
                          <span className={`font-bold ${results.deflectionOk ? 'text-emerald-500' : 'text-rose-500'}`}>{formatNum(results.Ld_real, 1)} <span className="text-[10px] text-slate-400">/ {formatNum(results.limitLd, 1)}</span></span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          )}

          {activeTab === 'results' && (
            <motion.div 
              key="results"
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.98 }}
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
            >
              <div className="bg-white border border-slate-200 rounded-3xl p-8 shadow-sm">
                <h3 className="text-lg font-bold text-slate-800 mb-6 flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-blue-50 text-blue-500 flex items-center justify-center"><Layers size={18}/></div>
                  Paramètres Calculés
                </h3>
                <div className="space-y-4">
                  {[
                    { label: 'fcd (MPa)', val: results.fcd, formula: 'fck / γc' },
                    { label: 'fctm (MPa)', val: results.fctm, formula: '0.3·fck^(2/3)' },
                    { label: 'cnom (mm)', val: results.cnom, formula: 'cmin + Δcdev' },
                    { label: 'd (mm)', val: results.d, formula: 'h - cnom - ϕ/2' },
                    { label: 'Ecm (MPa)', val: results.Ecm, formula: '22000·(fck/10)^0.3' },
                  ].map((it, idx) => (
                    <div key={idx} className="flex justify-between items-center p-3 rounded-xl hover:bg-slate-50 transition-colors">
                      <div>
                        <span className="text-sm font-medium text-slate-600 block">{it.label}</span>
                        <span className="text-[10px] text-slate-400 font-mono italic">{it.formula}</span>
                      </div>
                      <span className="font-bold text-slate-900">{formatNum(it.val)}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-white border border-slate-200 rounded-3xl p-8 shadow-sm">
                <h3 className="text-lg font-bold text-slate-800 mb-6 flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-indigo-50 text-indigo-500 flex items-center justify-center"><Layout size={18}/></div>
                  Sollicitations ELU
                </h3>
                <div className="space-y-4">
                   {[
                    { label: 'Mom. Tr. X (kNm)', val: results.MEd_x, formula: 'αx·pu·Lx²' },
                    { label: 'Mom. Tr. Y (kNm)', val: results.MEd_y, formula: state.appuiType === AppuiType.FourSides ? 'αy·pu·Lx²' : '-' },
                    { label: 'Mom. Appui (kNm)', val: results.MEd_app_x, formula: 'Encastrement' },
                    { label: 'Eff. Tranchant (kN)', val: results.VEd, formula: 'pu·Lx/2' },
                  ].map((it, idx) => (
                    <div key={idx} className="flex justify-between items-center p-3 rounded-xl hover:bg-slate-50 transition-colors">
                      <div>
                        <span className="text-sm font-medium text-slate-600 block">{it.label}</span>
                        <span className="text-[10px] text-slate-400 font-mono italic">{it.formula}</span>
                      </div>
                      <span className="font-bold text-slate-900">{typeof it.val === 'number' ? formatNum(it.val) : it.val}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-white border border-slate-200 rounded-3xl p-8 shadow-sm">
                <h3 className="text-lg font-bold text-slate-800 mb-6 flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-500 flex items-center justify-center"><Calculator size={18}/></div>
                  Section d'Acier
                </h3>
                <div className="space-y-4">
                  {[
                    { label: 'Moment réduit μ', val: results.mu, formula: 'MEd / (b·d²·fcd)' },
                    { label: 'Bras de levier z', val: results.z, formula: 'd(1-0.5α)' },
                    { label: 'As min (cm²/m)', val: results.As_min_mm2/100, formula: 'max(ρmin·bd; 0.0013bd)' },
                    { label: 'As req (cm²/m)', val: results.As_req_x/100, formula: 'max(As,th; As,min)' },
                  ].map((it, idx) => (
                    <div key={idx} className="flex justify-between items-center p-3 rounded-xl hover:bg-slate-50 transition-colors">
                      <div>
                        <span className="text-sm font-medium text-slate-600 block">{it.label}</span>
                        <span className="text-[10px] text-slate-400 font-mono italic">{it.formula}</span>
                      </div>
                      <span className={`font-bold ${it.label === 'Moment réduit μ' && it.val > 0.372 ? 'text-rose-500' : 'text-slate-900'}`}>{formatNum(it.val, it.label.includes('μ') ? 4 : 2)}</span>
                    </div>
                  ))}
                </div>
              </div>
            </motion.div>
          )}

          {activeTab === 'checks' && (
            <motion.div 
              key="checks"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
            >
              {[
                { title: 'Moment réduit μ', val: `${formatNum(results.mu, 4)} / 0,372`, desc: 'Contraintes de compression du béton', ok: results.mu <= 0.372 },
                { title: 'Effort Tranchant', val: `${formatNum(results.VEd, 1)} / ${formatNum(results.VRd_c, 1)} kN`, desc: 'Vérification sans armatures transversales', ok: results.shearOk },
                { title: 'Flèche (L/d)', val: `${formatNum(results.Ld_real, 1)} / ${formatNum(results.limitLd, 1)}`, desc: 'Contrôle de la déformation élastique', ok: results.deflectionOk },
                { title: 'Contrainte Acier (ELS)', val: `${formatNum(results.sigma_s, 0)} / ${formatNum(0.8*state.fyk, 0)} MPa`, desc: 'Limitation des contraintes en service', ok: results.steelOk },
                { title: 'Fissuration (wk)', val: `${formatNum(results.wk, 3)} / ${formatNum(results.w_max, 1)} mm`, desc: 'Ouverture des fissures calculée', ok: results.crackOk },
                { title: 'Poinçonnement', val: results.punchActive ? `${formatNum(results.VEd_punch, 1)} / ${formatNum(results.VRd_c_punch, 1)} kN` : 'N/A', desc: 'Vérification au droit des appuis', ok: !results.punchActive || results.punchingOk },
              ].map((c, i) => (
                <div key={i} className={`p-8 rounded-3xl border-l-[6px] shadow-sm flex flex-col justify-between transition-all hover:scale-[1.02] ${
                  c.ok === true ? 'bg-emerald-50/50 border-emerald-500 text-emerald-950' : 
                  c.ok === false ? 'bg-rose-50/50 border-rose-500 text-rose-950' :
                  'bg-slate-50 border-slate-300 text-slate-800'
                }`}>
                  <div className="flex justify-between items-start mb-6">
                    <div>
                      <h4 className="font-black text-lg mb-1">{c.title}</h4>
                      <p className="text-xs opacity-60 font-medium">{c.desc}</p>
                    </div>
                    {c.ok ? <CheckCircle2 className="text-emerald-500" size={28} strokeWidth={2.5}/> : <AlertCircle className="text-rose-500" size={28} strokeWidth={2.5}/>}
                  </div>
                  <div>
                    <span className="text-2xl font-black block">{c.val}</span>
                    <span className="text-[10px] font-bold uppercase tracking-widest opacity-40">Valeur / Limite</span>
                  </div>
                </div>
              ))}
            </motion.div>
          )}

          {activeTab === 'reinforcement' && (
            <motion.div 
              key="reinforcement"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-8"
            >
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="bg-white border border-slate-200 rounded-3xl p-8 shadow-sm">
                  <h3 className="text-lg font-bold text-slate-800 mb-8 pb-4 border-bottom border-slate-100 flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-blue-50 text-blue-500 flex items-center justify-center"><Layers size={18}/></div>
                    Nappe Inférieure - Sens Lx
                  </h3>
                  <div className="space-y-6">
                    <div className="space-y-2">
                       <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Diamètre choisi</label>
                       <select 
                        value={state.diam_inf_x} 
                        onChange={(e) => updateState({ diam_inf_x: parseInt(e.target.value) })}
                        className="w-full bg-slate-50 border border-slate-100 rounded-xl px-4 py-3 font-semibold focus:ring-2 focus:ring-blue-100 transition-all outline-none"
                      >
                        {DIAM_OPTIONS.map(d => <option key={d} value={d}>ϕ {d} mm</option>)}
                      </select>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="bg-slate-50 p-4 rounded-2xl">
                        <span className="text-[10px] font-bold text-slate-400 uppercase block mb-1">Espacement</span>
                        <span className="text-xl font-black text-slate-900">{Math.round(results.esp_x_final)} <span className="text-xs">mm</span></span>
                      </div>
                      <div className="bg-slate-50 p-4 rounded-2xl">
                        <span className="text-[10px] font-bold text-slate-400 uppercase block mb-1">As Réel</span>
                        <span className="text-xl font-black text-slate-900">{formatNum(results.As_reel_x/100, 2)} <span className="text-xs">cm²/m</span></span>
                      </div>
                    </div>
                  </div>
                </div>

                {state.appuiType === AppuiType.FourSides && (
                  <div className="bg-white border border-slate-200 rounded-3xl p-8 shadow-sm">
                    <h3 className="text-lg font-bold text-slate-800 mb-8 pb-4 border-bottom border-slate-100 flex items-center gap-3">
                      <div className="w-8 h-8 rounded-lg bg-indigo-50 text-indigo-500 flex items-center justify-center"><Layers size={18}/></div>
                      Nappe Inférieure - Sens Ly
                    </h3>
                    <div className="space-y-6">
                      <div className="space-y-2">
                         <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Diamètre choisi</label>
                         <select 
                          value={state.diam_inf_y} 
                          onChange={(e) => updateState({ diam_inf_y: parseInt(e.target.value) })}
                          className="w-full bg-slate-50 border border-slate-100 rounded-xl px-4 py-3 font-semibold focus:ring-2 focus:ring-blue-100 transition-all outline-none"
                        >
                          {DIAM_OPTIONS.map(d => <option key={d} value={d}>ϕ {d} mm</option>)}
                        </select>
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div className="bg-slate-50 p-4 rounded-2xl">
                          <span className="text-[10px] font-bold text-slate-400 uppercase block mb-1">Espacement</span>
                          <span className="text-xl font-black text-slate-900">{Math.round(results.esp_y_final)} <span className="text-xs">mm</span></span>
                        </div>
                        <div className="bg-slate-50 p-4 rounded-2xl">
                          <span className="text-[10px] font-bold text-slate-400 uppercase block mb-1">As Réel</span>
                          <span className="text-xl font-black text-slate-900">{formatNum(results.As_reel_y/100, 2)} <span className="text-xs">cm²/m</span></span>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>

               <div className="bg-white border border-slate-200 rounded-3xl p-8 shadow-sm">
                <h3 className="text-lg font-bold text-slate-800 mb-8 pb-4 border-bottom border-slate-100 flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-amber-50 text-amber-500 flex items-center justify-center"><Maximize2 size={18}/></div>
                  Ancrage & Recouvrement
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {[
                    { label: 'lb,rqd (mm)', val: results.lb_rqd, desc: 'Sortie directe EC2' },
                    { label: 'Recouvrement l0 (mm)', val: results.l0, desc: 'α6 = 1,2' },
                    { label: 'Ancrage lbd (mm)', val: results.lbd, desc: 'α1 = 1,0' },
                  ].map((it, i) => (
                    <div key={i} className="p-6 rounded-2xl bg-slate-50 border border-slate-100 transition-all hover:bg-white hover:border-blue-100 shadow-sm group">
                      <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-2">{it.label}</span>
                      <span className="text-2xl font-black text-slate-900 group-hover:text-blue-600 transition-colors">{Math.round(it.val)}</span>
                      <p className="text-[10px] text-slate-400 mt-2 font-medium">{it.desc}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Nomenclature Section (BBS) */}
              <div className="bg-white border border-slate-200 rounded-3xl p-8 shadow-sm">
                <h3 className="text-xl font-black text-slate-800 mb-8 flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-500 flex items-center justify-center shrink-0">
                    <Hash size={24}/>
                  </div>
                  Nomenclature des Aciers (BBS)
                </h3>
                
                <div className="overflow-x-auto">
                  <table className="w-full border-collapse">
                    <thead>
                      <tr className="bg-slate-50 text-slate-500 text-[10px] uppercase font-bold tracking-widest border-b border-slate-100">
                        <th className="px-6 py-4 text-left">Rep</th>
                        <th className="px-6 py-4 text-left">Désignation</th>
                        <th className="px-6 py-4 text-center">ϕ (mm)</th>
                        <th className="px-6 py-4 text-center">Nb</th>
                        <th className="px-6 py-4 text-center">Long (m)</th>
                        <th className="px-6 py-4 text-center">Esp (mm)</th>
                        <th className="px-6 py-4 text-right">Poids (kg)</th>
                      </tr>
                    </thead>
                    <tbody className="text-sm font-semibold text-slate-700">
                      <tr className="border-b border-slate-50 hover:bg-slate-50/50 transition-colors">
                        <td className="px-6 py-4">1</td>
                        <td className="px-6 py-4">Aciers Porteurs (Inf. Lx)</td>
                        <td className="px-6 py-4 text-center">{state.diam_inf_x}</td>
                        <td className="px-6 py-4 text-center">{results.qty_x}</td>
                        <td className="px-6 py-4 text-center">{state.Lx}</td>
                        <td className="px-6 py-4 text-center">{Math.round(results.esp_x_final)}</td>
                        <td className="px-6 py-4 text-right">{formatNum(results.weight_x, 2)}</td>
                      </tr>
                      <tr className="border-b border-slate-50 hover:bg-slate-50/50 transition-colors">
                        <td className="px-6 py-4">2</td>
                        <td className="px-6 py-4">{state.appuiType === AppuiType.FourSides ? "Aciers Porteurs (Inf. Ly)" : "Aciers de Répartition (Ly)"}</td>
                        <td className="px-6 py-4 text-center">{state.appuiType === AppuiType.FourSides ? state.diam_inf_y : 8}</td>
                        <td className="px-6 py-4 text-center">{results.qty_y}</td>
                        <td className="px-6 py-4 text-center">{state.Ly}</td>
                        <td className="px-6 py-4 text-center">{Math.round(results.esp_y_final)}</td>
                        <td className="px-6 py-4 text-right">{formatNum(results.weight_y, 2)}</td>
                      </tr>
                      {results.weight_top > 0 && (
                        <tr className="border-b border-slate-50 hover:bg-slate-50/50 transition-colors">
                          <td className="px-6 py-4">3</td>
                          <td className="px-6 py-4">Armatures de Chapeaux (Appuis)</td>
                          <td className="px-6 py-4 text-center">{state.diam_inf_x}</td>
                          <td className="px-6 py-4 text-center">{results.qty_top}</td>
                          <td className="px-6 py-4 text-center">{results.len_top}</td>
                          <td className="px-6 py-4 text-center">200</td>
                          <td className="px-6 py-4 text-right text-indigo-600">{formatNum(results.weight_top, 2)}</td>
                        </tr>
                      )}
                      <tr className="bg-slate-900 text-white font-black">
                        <td colSpan={6} className="px-6 py-4 text-right uppercase tracking-[0.2em] text-[10px]">Poids Total de l'Acier</td>
                        <td className="px-6 py-4 text-right text-blue-400">{formatNum(results.weight_total, 2)} kg</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </motion.div>
          )}



          {activeTab === 'help' && (
            <motion.div 
              key="help"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="bg-white border border-slate-200 rounded-3xl p-8 md:p-12 shadow-sm prose prose-slate max-w-none no-scrollbar overflow-y-auto max-h-[80vh]"
            >
              <div className="max-w-4xl mx-auto">
                <header className="border-b-2 border-blue-100 pb-10 mb-12 text-center">
                  <div className="inline-flex items-center justify-center w-20 h-20 bg-blue-50 text-blue-600 rounded-2xl mb-6 shadow-sm border border-blue-100">
                    <HelpCircle size={40} />
                  </div>
                  <h1 className="text-4xl font-black text-slate-900 mb-4 tracking-tight">Manuel d'Utilisation Expert</h1>
                  <p className="text-xl text-slate-500 font-medium">Guide complet de dimensionnement aux Eurocodes — S.E.L.</p>
                </header>

                <section className="mb-16">
                  <h2 className="text-2xl font-black text-slate-900 flex items-center gap-4 mb-8">
                    <span className="flex items-center justify-center w-10 h-10 rounded-xl bg-blue-600 text-white text-lg">01</span>
                    Onglet : Données de Conception
                  </h2>
                  <p className="text-slate-600 leading-relaxed mb-6">
                    Cet onglet est le point d'entrée de votre projet. Une saisie rigoureuse garantit la validité du modèle de calcul.
                  </p>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="bg-slate-50 p-6 rounded-2xl border border-slate-100">
                      <h4 className="font-bold text-blue-600 mb-3 flex items-center gap-2"><Layout size={18}/> Géométrie & Appuis</h4>
                      <ul className="text-sm space-y-2 text-slate-500">
                        <li><span className="font-bold text-slate-700">Portées (Lx, Ly) :</span> Entrez les distances entre nus d'appuis. Lx est toujours la petite portée.</li>
                        <li><span className="font-bold text-slate-700">Type d'Appui :</span> '4 côtés' active le calcul en dalle bi-directionnelle (abaques de Pigeaud/Bares). '2 côtés' traite la dalle en poutre.</li>
                        <li><span className="font-bold text-slate-700">Conditions de Bord :</span> Définit la continuité (articulé, encastré).</li>
                      </ul>
                    </div>
                    <div className="bg-slate-50 p-6 rounded-2xl border border-slate-100">
                      <h4 className="font-bold text-blue-600 mb-3 flex items-center gap-2"><Settings size={18}/> Matériaux & Charges</h4>
                      <ul className="text-sm space-y-2 text-slate-500">
                        <li><span className="font-bold text-slate-700">Béton (fck) :</span> Résistances standard (C25/30, C30/37).</li>
                        <li><span className="font-bold text-slate-700">Enrobage (cnom) :</span> Calculé selon l'exposition (XC, XD). Critique pour la durabilité.</li>
                        <li><span className="font-bold text-slate-700">Charges (G, Qk) :</span> Ginclut le poids propre auto-calculé + finitions. Qk dépend de la destination du local.</li>
                      </ul>
                    </div>
                  </div>
                </section>

                <section className="mb-16">
                  <h2 className="text-2xl font-black text-slate-900 flex items-center gap-4 mb-8">
                    <span className="flex items-center justify-center w-10 h-10 rounded-xl bg-blue-600 text-white text-lg">02</span>
                    Onglet : Résultats d'Analyse
                  </h2>
                  <p className="text-slate-600 leading-relaxed mb-6">
                    Visualisez les paramètres dérivés et les sollicitations de calcul à l'État Limite Ultime (ELU).
                  </p>
                  <div className="space-y-4">
                    <div className="p-5 border-l-4 border-blue-500 bg-blue-50/30 rounded-r-xl">
                      <h4 className="font-bold text-slate-800">Moments Fléchissants (MEd)</h4>
                      <p className="text-sm text-slate-500">Affiche les moments en travée (Mx, My) et aux appuis après application des coefficients Eurocode. C'est ici que vous vérifiez la répartition des efforts.</p>
                    </div>
                    <div className="p-5 border-l-4 border-blue-500 bg-blue-50/30 rounded-r-xl">
                      <h4 className="font-bold text-slate-800">Paramètres de Section (d, z, mu)</h4>
                      <p className="text-sm text-slate-500">Hauteur utile (d), bras de levier (z) et moment réduit (mu). Un mu &gt; 0.372 indique la nécessité d'aciers comprimés (rare en dalle, préférez épaissir).</p>
                    </div>
                  </div>
                </section>

                <section className="mb-16">
                  <h2 className="text-2xl font-black text-slate-900 flex items-center gap-4 mb-8">
                    <span className="flex items-center justify-center w-10 h-10 rounded-xl bg-blue-600 text-white text-lg">03</span>
                    Onglet : Vérifications Réglementaires
                  </h2>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div className="p-6 rounded-2xl border border-slate-100 bg-white shadow-sm flex flex-col items-center text-center">
                      <div className="w-12 h-12 bg-rose-50 text-rose-500 rounded-full flex items-center justify-center mb-4"><Zap size={24}/></div>
                      <h4 className="font-bold text-sm mb-2">Cisaillement</h4>
                      <p className="text-xs text-slate-500">VEd vs VRd,c (EC2 6.2). Si fail, la dalle risque une rupture brutale.</p>
                    </div>
                    <div className="p-6 rounded-2xl border border-slate-100 bg-white shadow-sm flex flex-col items-center text-center">
                      <div className="w-12 h-12 bg-amber-50 text-amber-500 rounded-full flex items-center justify-center mb-4"><Maximize2 size={24}/></div>
                      <h4 className="font-bold text-sm mb-2">Poinçonnement</h4>
                      <p className="text-xs text-slate-500">Crucial si la dalle repose sur des poteaux isolés (EC2 6.4).</p>
                    </div>
                    <div className="p-6 rounded-2xl border border-slate-100 bg-white shadow-sm flex flex-col items-center text-center">
                      <div className="w-12 h-12 bg-emerald-50 text-emerald-500 rounded-full flex items-center justify-center mb-4"><Activity size={24}/></div>
                      <h4 className="font-bold text-sm mb-2">Fissuration</h4>
                      <p className="text-xs text-slate-500">Ouverture wk &lt; w_lim. Garantit la non-corrosion des aciers.</p>
                    </div>
                  </div>
                </section>

                <section className="mb-16">
                  <h2 className="text-2xl font-black text-slate-900 flex items-center gap-4 mb-8">
                    <span className="flex items-center justify-center w-10 h-10 rounded-xl bg-blue-600 text-white text-lg">04</span>
                    Ferraillage & Nomenclature (BBS)
                  </h2>
                  <div className="bg-slate-900 rounded-3xl p-8 text-white">
                    <div className="flex flex-col md:flex-row gap-8">
                      <div className="flex-1">
                        <h4 className="font-bold text-blue-400 mb-4 tracking-wider uppercase text-xs">Section Ferraillage</h4>
                        <p className="text-sm text-slate-400 leading-relaxed">
                          Définit les diamètres et les espacements réels. L'algorithme calcule également la <strong>longueur d'ancrage (lbd)</strong> nécessaire pour assurer la transmission des efforts au béton sans glissement.
                        </p>
                      </div>
                      <div className="flex-1">
                        <h4 className="font-bold text-blue-400 mb-4 tracking-wider uppercase text-xs">Section Nomenclature</h4>
                        <p className="text-sm text-slate-400 leading-relaxed">
                          Génère un tableau récapitulatif (BBS) avec le nombre de barres, les longueurs unitaires et le <strong>poids total</strong> par type d'acier. Essentiel pour les devis et les commandes d'armatures.
                        </p>
                      </div>
                    </div>
                  </div>
                </section>

                <section className="mb-12">
                  <h2 className="text-2xl font-black text-slate-900 flex items-center gap-4 mb-8">
                    <span className="flex items-center justify-center w-10 h-10 rounded-xl bg-blue-600 text-white text-lg">05</span>
                    Export de la Note de Calcul
                  </h2>
                  <p className="text-slate-600 mb-6">
                    Le couronnement de votre étude. L'onglet 'Note de Calcul' synthétise l'ensemble des hypothèses et des résultats dans un format professionnel prêt à être imprimé ou exporté en <strong>PDF</strong>.
                  </p>
                  <div className="bg-blue-600 p-1 rounded-2xl">
                     <div className="bg-white p-6 rounded-xl border border-blue-200">
                        <p className="text-sm font-bold text-slate-800 flex items-center gap-2">
                          <FileText className="text-blue-600" size={18}/> Astuce :
                        </p>
                        <p className="text-xs text-slate-500 mt-2">
                          Utilisez le bouton "Exporter PDF" pour générer un document officiel incluant le cachet de <strong>Structural & Engineering Labs</strong>, valable pour les bureaux de contrôle.
                        </p>
                     </div>
                  </div>
                </section>

                <footer className="pt-12 border-t border-slate-100 flex flex-col md:flex-row justify-between items-center gap-6">
                  <SEL_Logo className="scale-75 origin-left" />
                  <div className="text-center md:text-right">
                    <p className="text-[10px] text-slate-400 font-black uppercase tracking-[0.2em] mb-1">Support & Expertise</p>
                    <p className="text-sm font-bold text-slate-700">structuralengineeringlabs@gmail.com</p>
                  </div>
                </footer>
              </div>
            </motion.div>
          )}

          {activeTab === 'report' && (
            <motion.div 
              key="report"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="bg-white border border-slate-200 rounded-3xl p-8 md:p-12 shadow-sm min-h-[600px] prose prose-slate max-w-none"
            >
              <div dangerouslySetInnerHTML={{ __html: generateNoteDeCalcul(state, results, projectName) }} />
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      <footer className="max-w-7xl mx-auto mt-20 py-10 border-t border-slate-200">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
          <div className="text-center md:text-left">
            <p className="text-slate-900 font-bold text-sm">© {new Date().getFullYear()} Structural & Engineering Labs</p>
            <p className="text-slate-400 text-xs mt-1">Conformité NF EN 1992-1-1 • Application professionnelle</p>
          </div>
          <div className="text-center md:text-right space-y-1">
            <p className="text-xs text-slate-500 font-medium">Contact : structuralengineeringlabs@gmail.com</p>
            <p className="text-xs text-slate-500 font-medium">Tél : +237 6 51 13 56 05</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
