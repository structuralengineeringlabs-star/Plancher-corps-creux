
export enum AppuiType {
  TwoSides = "2cotes",
  FourSides = "4cotes",
}

export enum BorderCondition {
  SimplySupported = "simplement_appuye",
  Continuous = "continu",
  Fixed = "encastre",
}

export enum ColumnPosition {
  Central = "central",
  Edge = "rive",
  Corner = "angle",
}

export interface CalculationState {
  appuiType: AppuiType;
  borderCond: BorderCondition;
  fck: number;
  fyk: number;
  exposure: string;
  structClass: string;
  deltaCdev: number;
  h: number; // thickness in mm
  Lx: number; // effective span in m
  Ly: number; // effective span in m
  phi: number; // main rebar diameter in mm
  g1: number; // additional dead load kN/m2
  qkCategoryIndex: number;
  diam_inf_x: number;
  diam_inf_y: number;
  checkPunching: boolean;
  columnSize: number; // mm
  columnPosition: ColumnPosition;
}

export interface CalculationResults {
  fck: number;
  fcd: number;
  fctm: number;
  fyk: number;
  fyd: number;
  cmin_dur: number;
  cmin: number;
  cnom: number;
  d: number;
  g0: number;
  g_total: number;
  qk: number;
  pu: number;
  pser_qp: number;
  MEd_x: number;
  MEd_y: number;
  MEd_app_x: number;
  VEd: number;
  MEd_max: number;
  mu: number;
  muSafe: number;
  z: number;
  As_th_mm2: number;
  rhoMin: number;
  As_min_mm2: number;
  As_used_mm2: number;
  As_req_x: number;
  As_req_y: number;
  rho_l: number;
  VRd_c: number;
  shearOk: boolean;
  Ld_real: number;
  limitLd: number;
  deflectionOk: boolean;
  Ecm: number;
  alpha_e: number;
  x: number;
  Icr: number;
  sigma_s: number;
  steelOk: boolean;
  w_max: number;
  wk: number;
  crackOk: boolean;
  punchingOk: boolean;
  VRd_c_punch: number;
  VEd_punch: number;
  punchActive: boolean;
  lb_rqd: number;
  l0: number;
  lbd: number;
  esp_x_final: number;
  As_reel_x: number;
  esp_y_final: number;
  As_reel_y: number;
  coeffs: any;
  rho_l_punch: number;
  weight_total: number;
  weight_x: number;
  weight_y: number;
  qty_x: number;
  qty_y: number;
  weight_top: number;
  len_top: number;
  qty_top: number;
}
